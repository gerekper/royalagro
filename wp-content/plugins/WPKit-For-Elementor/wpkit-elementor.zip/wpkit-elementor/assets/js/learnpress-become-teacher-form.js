(function($){
	"use strict";

	$('.non-logged-in input, .non-logged-in textarea').attr('readonly', 'readonly');
})(jQuery);